<?php
require_once '../includes/header.php'; 
?>

<h1>به پنل مدیریت محصولات خوش آمدید</h1>
<p>از طریق منوی بالا می‌توانید به بخش‌های مختلف دسترسی داشته باشید.</p>
<ul>
    <li><strong>لیست محصولات:</strong> مشاهده، ویرایش و حذف محصولات موجود.</li>
    <li><strong>افزودن محصول:</strong> افزودن یک کالای جدید به فروشگاه.</li>
</ul>

<?php
require_once '../includes/footer.php'; 
?>